// ============================================================
// My-Mock — email verification + Google Sheet logging
// ------------------------------------------------------------
// This matches the pattern from your previous working site:
// ONE Google Apps Script, bound to a Google Sheet owned by
// easyieltsforeveryone@gmail.com, handles both jobs:
//   - GmailApp.sendEmail(...) sends the real verification code
//   - SpreadsheetApp logs verified students into the Sheet
//
// See server/Code.gs for the script itself and server/DEPLOY.md
// for the 5-minute deployment steps. Once deployed, paste the
// Web App URL below and both features go live — no separate
// email service or Node server needed.
// ============================================================

const CONFIG = {
  GAS_WEBAPP_URL: "https://script.google.com/macros/s/AKfycbypvxG6JOfYZa-RGHtOzqOKUN8dpfU2jZv_QoTo2641ly1mLfp6uhiUb-7s78GnChg/exec",
};

async function callBackend(action, data) {
  if (!CONFIG.GAS_WEBAPP_URL) {
    return { ok: false, error: "not_configured" };
  }
  let res;
  try {
    res = await fetch(CONFIG.GAS_WEBAPP_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" }, // avoids a CORS preflight against Apps Script
      body: JSON.stringify({ action, ...data }),
    });
  } catch (e) {
    return { ok: false, error: "network", detail: String((e && e.message) || e) };
  }
  let text;
  try {
    text = await res.text();
  } catch (e) {
    return { ok: false, error: "network", detail: "Couldn't read the response body." };
  }
  try {
    return JSON.parse(text);
  } catch (e) {
    return { ok: false, error: "bad_response", detail: `HTTP ${res.status}: ${text.slice(0, 300)}` };
  }
}

const EmailService = {
  // Returns { sent: true } on success, or { simulated: true, code } in dev
  // mode (no backend configured yet) so signup stays testable end-to-end.
  async sendVerificationCode(toEmail, toName, code) {
    const result = await callBackend("sendCode", { email: toEmail, name: toName, code });

    if (result.ok) return { sent: true };

    if (result.error === "not_configured") {
      console.warn(
        `[My-Mock] Google Apps Script backend not connected yet — verification code for ${toEmail} is: ${code}\n` +
        `(Shown here only because email sending isn't set up. See server/DEPLOY.md.)`
      );
      window.__mymock_last_code = code;
      return { simulated: true, code };
    }

    throw new Error(result.detail || "Could not send verification email. Please try again.");
  },

  // The actual code check now happens server-side in Code.gs (single
  // source of truth — matches the old system, and means a code can't
  // be guessed/replayed purely from client-side localStorage).
  async verifyCodeServerSide(email, code, name) {
    if (!CONFIG.GAS_WEBAPP_URL) return null; // signals "fall back to local dev-mode check"
    return callBackend("verifyCode", { email, code, name });
  },
};

window.MyMock = window.MyMock || {};
window.MyMock.EmailService = EmailService;
window.MyMock.CONFIG = CONFIG;
