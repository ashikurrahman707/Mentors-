# Deploying the My-Mock email + Sheet backend (Google Apps Script)

This is the same approach your previous site used: one Google Apps
Script, bound to a Google Sheet, sends real verification emails via
your own Gmail account and logs verified students into that Sheet.
No separate server, no third-party email service, no App Password.

## 1. Create the Sheet (as easyieltsforeveryone@gmail.com)

1. Log into **easyieltsforeveryone@gmail.com** in your browser.
2. Go to **sheets.google.com** → create a new blank spreadsheet.
3. Name it something like "My-Mock Students".

This matters: whichever Google account owns the Sheet is the account
Gmail will send emails *from* — so it must be logged in as
`easyieltsforeveryone@gmail.com` when you do this.

## 2. Add the script

1. In the Sheet, go to **Extensions → Apps Script**.
2. Delete the placeholder code in the editor.
3. Paste in the full contents of `server/Code.gs` (included in this download).
4. Click the save icon, name the project "My-Mock Backend".

## 3. Deploy it as a Web App

1. Click **Deploy → New deployment**.
2. Click the gear icon next to "Select type" → choose **Web app**.
3. Set:
   - **Execute as:** Me (easyieltsforeveryone@gmail.com)
   - **Who has access:** Anyone
4. Click **Deploy**.
5. The first time, Google will ask you to **authorize** the script — click through (it'll warn "Google hasn't verified this app" since it's your own personal script; click **Advanced → Go to My-Mock Backend (unsafe)** — this warning is normal for private scripts you wrote yourself).
6. Copy the **Web app URL** it gives you — it ends in `/exec`.

## 4. Connect the site

Open `js/email.js`, find `CONFIG.GAS_WEBAPP_URL`, and paste your URL in:

```js
GAS_WEBAPP_URL: "https://script.google.com/macros/s/AKfycb.../exec",
```

That's it. Signup will now send real emails from
`easyieltsforeveryone@gmail.com`, and verified students automatically
appear in two tabs in your Sheet:
- **PendingVerification** — temporary, cleared once a code is used or replaced
- **Users** — permanent log of every verified student (name, email, verified timestamp)

## Updating the script later

If you ever edit `Code.gs` again, you must do **Deploy → Manage
deployments → edit (pencil icon) → New version → Deploy** — just saving
the file in the editor does NOT update the live Web App URL.

## Limits to know about

Google Apps Script has a daily email quota: **100 emails/day** for a
regular free Gmail account (much higher, 1,500/day, if the account is
a paid Google Workspace account). Fine for early testing and a
moderate number of students; if you outgrow it, that's the point to
revisit a dedicated email service.
