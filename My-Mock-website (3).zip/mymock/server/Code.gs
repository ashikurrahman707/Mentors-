// ============================================================
// My-Mock — Google Apps Script backend
// ------------------------------------------------------------
// Deploy this bound to a Google Sheet owned by
// easyieltsforeveryone@gmail.com (see server/DEPLOY.md).
// It sends real verification emails via GmailApp (no App
// Password, no Node server — just your Google account) and
// logs verified students into this same Sheet.
//
// The frontend calls this with POST requests shaped like:
//   { action: "sendCode", email, name }
//   { action: "verifyCode", email, code, name }
// ============================================================

const CODE_EXPIRY_MINUTES = 15;

function doPost(e) {
  let result;
  try {
    const data = JSON.parse(e.postData.contents);
    if (data.action === "sendCode") result = sendCode(data);
    else if (data.action === "verifyCode") result = verifyCode(data);
    else result = { ok: false, error: "unknown_action" };
  } catch (err) {
    result = { ok: false, error: "server_error", detail: String(err) };
  }
  return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(
    ContentService.MimeType.JSON
  );
}

function getSheet(name, headerRow) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (headerRow) sheet.appendRow(headerRow);
  }
  return sheet;
}

function sendCode(data) {
  const email = String(data.email || "").trim().toLowerCase();
  const name = String(data.name || "").trim();
  if (!email) return { ok: false, error: "Missing email." };

  const code = String(Math.floor(100000 + Math.random() * 900000));
  const pending = getSheet("PendingVerification", ["Email", "Name", "Code", "CreatedAt"]);
  removeRowsByColumnValue(pending, 1, email); // clear any earlier pending code for this email
  pending.appendRow([email, name, code, new Date().toISOString()]);

  GmailApp.sendEmail(email, "Your My-Mock verification code", "", {
    name: "My-Mock — IELTS Speaking Practice",
    htmlBody:
      '<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;">' +
      '<h2 style="color:#4F46E5;margin-bottom:4px;">My-Mock</h2>' +
      "<p>Hi " + (name || "there") + ",</p>" +
      "<p>Your IELTS Speaking Practice verification code is:</p>" +
      '<p style="font-size:32px;font-weight:bold;letter-spacing:6px;color:#111;">' + code + "</p>" +
      '<p style="color:#666;font-size:13px;">This code expires in ' + CODE_EXPIRY_MINUTES +
      " minutes. If you didn't request this, you can safely ignore this email.</p></div>",
  });

  return { ok: true };
}

function verifyCode(data) {
  const email = String(data.email || "").trim().toLowerCase();
  const code = String(data.code || "").trim();
  const name = String(data.name || "").trim();

  const pending = getSheet("PendingVerification", ["Email", "Name", "Code", "CreatedAt"]);
  const rows = pending.getDataRange().getValues();

  let rowIndex = -1, record = null;
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).toLowerCase() === email) { rowIndex = i; record = rows[i]; break; }
  }
  if (!record) return { ok: false, error: "No pending verification found. Please sign up again." };

  const [, storedName, storedCode, createdAt] = record;
  const ageMinutes = (Date.now() - new Date(createdAt).getTime()) / 60000;
  if (ageMinutes > CODE_EXPIRY_MINUTES) {
    return { ok: false, error: "This code has expired. Please request a new one." };
  }
  if (String(storedCode).trim() !== code) {
    return { ok: false, error: "Incorrect verification code." };
  }

  pending.deleteRow(rowIndex + 1);

  const users = getSheet("Users", ["Name", "Email", "VerifiedAt"]);
  const alreadyExists = !!findRowByColumnValue(users, 1, email);
  if (!alreadyExists) {
    users.appendRow([name || storedName, email, new Date().toISOString()]);
  }

  return { ok: true, isReturning: alreadyExists };
}

function removeRowsByColumnValue(sheet, colIndexZeroBased, value) {
  const rows = sheet.getDataRange().getValues();
  for (let i = rows.length - 1; i >= 1; i--) {
    if (String(rows[i][colIndexZeroBased]).toLowerCase() === value) sheet.deleteRow(i + 1);
  }
}

function findRowByColumnValue(sheet, colIndexZeroBased, value) {
  const rows = sheet.getDataRange().getValues();
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][colIndexZeroBased]).toLowerCase() === value) return rows[i];
  }
  return null;
}
